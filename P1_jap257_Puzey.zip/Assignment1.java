import java.util.*;

public class Assignment1 {
    
    //main method to implement user input to the program
    public static void main (String[] args) {
      
      //prints the options for the different methods contained in the app
      System.out.println ("Welcome to the App!"+ "\n" +"   1. Palindrome Check" + "\n" + "   2. Annagram Check" + "\n" 
                            +"   3. Add Substring" + "\n" + "   4. Get Length" + "\n" +"   5. Count Occurrences" + "\n" 
                            + "   6. Reverse Sentence" + "\n" + "   7. Quit" + "\n" + "Choose an option:");
      
      //creates a scanner to read user input
      Scanner sc= new Scanner(System.in);
      String str= sc.nextLine();  
      
      //if user chooses palindrome check
      if (str.equals("1")){
        
        System.out.println("Enter string: ");
        Scanner sc2 = new Scanner(System.in);
        String palindrome = sc2.nextLine();
        
        //calls the iterative approach to the palindrome check
        boolean palCheck = palindromeIterative(palindrome);
        System.out.println("The input string is a palindrome: " + palCheck + "!");
 
        
      }
      
      //if the user chooses the anagram checker
      if (str.equals("2")){
        
        System.out.println("Enter first string:");
        Scanner sc2= new Scanner(System.in);
        String x = sc2.nextLine();
        System.out.println("Enter second string:");
        String y = sc2.nextLine();
        
        //runs the method with the user's input string and substring
        boolean answer = anagramChecker(x, y);
        
        //prints out the answer
        System.out.println("These strings are anagrams: " + answer + "!");
      }
      
      //if the user chooses add substring
      if (str.equals("3")){
        
        System.out.println("Enter string:");
        Scanner sc2= new Scanner(System.in);
        String input = sc2.nextLine();
        System.out.println("Substring to be inserted:");
        String substring = sc2.nextLine();
        System.out.println("Index Placement:");
        int index = sc2.nextInt();
        
        //runs the method with the user's input string and substring
        String newString = addSubstring(input, substring, index);
        
        //prints out the new string with the inputted substring
        System.out.println("New String: " + newString);
      }
      
      //if the user chooses get length
      if (str.equals("4")){
        
        System.out.println("Enter String:");
        Scanner sc2 = new Scanner(System.in);
        String input = sc2.nextLine();
        
        int length = getLength(input);
        System.out.println("The length of the string is: " + length);

      }
      
      //if the user chooses the occurrence counter
      if (str.equals("5")){
        
        System.out.println("Input String:");
        Scanner sc2= new Scanner(System.in);
        String input = sc2.nextLine();
        System.out.println("Substring:");
        String sub = sc2.nextLine();
        
        //runs the method with the user's input string and substring
        int count = occurrenceCounter(input, sub);
        
        //prints out the count
        System.out.println("The number of occurrences of the substring is: " + count);
      }
      
      //if the user chooses sentence reversal
      if (str.equals("6")){
        
        System.out.println("Input sentence to be reversed:");
        Scanner sc2 = new Scanner(System.in);
        String toReverse = sc2.nextLine();
        String reversed = sentenceReversal(toReverse);
        System.out.println("The reversed sentence is: " + reversed);

      }
      
      //if the user chooses to quit
      if (str.equals("7")){
        System.out.println("Have a nice day :)");
      }
    }
    
    /*iterative approach to determine if a string is a palindrome
     * this method has a time complexity of O(n)
     * both approaches to the palindrome method have the same time complexity
     * however, the iterative approach is less complex in terms of spaces complexity so it is more efficient
    */
    public static boolean palindromeIterative(String input){
      
        int left = 0;
        int right = input.length() - 1;

        while (left < right) {
            if (input.charAt(left) != input.charAt(right)) {
                return false; 
            }
            left++;
            right--;
        }

        return true; 
    }
    
    /*recursive approach to determine if an input string is a palindrome
     * this method has a time complexity of O(n)
    */
    public static boolean palindromeRecursive(String str){
      
        //if string is empty or only one character long (base case)
        if (str.length() <= 1) {
            return true;
        }

        //compares the first character with the last character
        char first = str.charAt(0);
        char last = str.charAt(str.length() - 1);

        //rules out if the first and last character aren't the same
        if (first != last) {
            return false;
        }

        //recursively checks the substring which is the characters in the middle
        String substring = str.substring(1, str.length() - 1);
        return palindromeRecursive(substring);
    }
    
    //method to check if 2 input strings are anagrams of each other
    public static boolean anagramChecker(String x, String y){
      
      //base cases:
      // both strings are empty
      if (x.isEmpty() && y.isEmpty()) {
        return true; 
      }
      
      //if the strings are different lengths (they can't be anagrams in this case)
      if (x.length() != y.length()) {
        return false; 
      }
      
      // picks first character from string x
      char currentChar = x.charAt(0);
      
      // checks for that character in the other string
      int charIndex = y.indexOf(currentChar);
      
      //if that character isn't in the other string they can't be anagrams
      if (charIndex == -1) {
        return false; 
      }
      
      // removes the character from both strings 
      String newX = x.substring(1);
      String newY = y.substring(0, charIndex) + y.substring(charIndex + 1);
      
      return anagramChecker(newX, newY);
    }

    public static String addSubstring(String input, String substring, int index){
      
        //adds substring at beginning if index is 0 or less (base case)
        if (index <= 0) {
            return substring + input;
        }

        // recursively adds substring by taking substrings before and after index
        String before = input.substring(0, index);
        String after = input.substring(index);

        return before + substring + after;
    }

    
    //method to return the length of an input string
    public static int getLength(String input){
      
      //uses length function of String
      return input.length();
    }

    public static int occurrenceCounter(String input, String substring){
        int inputLength = input.length();
        int substringLength = substring.length();

        // base case: if input string is shorter than the substring
        if (inputLength < substringLength) {
            return 0;
        }

        // if substring is at the beginning of input string
        if (input.substring(0, substringLength).equals(substring)) {
          
            // recursively check the rest of the string and add to counter
            return 1 + occurrenceCounter(input.substring(substringLength), substring);  
        } 
        
        else 
            // otherwise, recursively check the rest of the string (don't add to counter)
            return occurrenceCounter(input.substring(1), substring);
    }
    
    public static String sentenceReversal(String toReverse){
      // if the input is empty, base case
        if (toReverse == null) {
            return toReverse;
        }

        //sees where the last space was in sentence
        int lastSpaceIndex = toReverse.lastIndexOf(' ');

        // no spaces, only one word was inputted
        if (lastSpaceIndex == -1) {
            return toReverse;
        }

        // removes last word of sentence
        String lastWord = toReverse.substring(lastSpaceIndex + 1);
        String remainingSentence = toReverse.substring(0, lastSpaceIndex);

        // recursively reverses the rest of the sentence
        String reversedSentence = lastWord + " " + sentenceReversal(remainingSentence)  ;
        
        //returns the reversed sentence
        return reversedSentence;
    }
}

